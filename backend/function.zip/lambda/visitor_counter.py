import json
import boto3
db = boto3.resource('dynamodb')
table = db.Table('Cloud-Resume-Challenge-visit-counter')

def lambda_handler(event, context):
    try: 
        reponse = table.update_item(
            Key={'id': 'couter_id'},
            UpdateExpression='ADD visit_count :incr',
            ExpressionAttributeValues={':incr': 1},
            ReturnValues='UPDATED_NEW'
        )
 # Extract the new count
        couter_id = int(response['Attributes']['visits'])
        
        # Return successful response
        return {
            'statusCode': 200,
            'headers': {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*',  # CORS for your domain
                'Access-Control-Allow-Methods': 'POST, OPTIONS',
                'Access-Control-Allow-Headers': 'Content-Type'
            },
            'body': json.dumps({
                'count': couter_id,
                'message': 'Visitor count updated successfully'
            })
        }
        
    except Exception as e:
        # Log error to CloudWatch
        print(f"Error: {str(e)}")
        
        # Return error response
        return {
            'statusCode': 500,
            'headers': {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*'
            },
            'body': json.dumps({
                'error': 'Internal server error',
                'message': str(e)
            })
        }
